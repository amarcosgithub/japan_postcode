<?php
error_reporting(0);
$host="localhost";
$user="root";
$password="";
$db="postcodes2222";
$conn = new mysqli($host, $user, $password, $db);

if(!$conn){
    die("Connection Failed: ". $conn->conect_error);
}


$filter = $_REQUEST['content'];

if($filter){
    $filter2 = '%' . $filter . "%";
    $SQL = $conn->prepare("select * from jp_postcodes where postcode like ? order by ename");
    $SQL->bind_param("s",$filter2);
} else {
    $SQL = $conn->prepare("select * from jp_postcodes by postcode");
}

$SQL->execute();
$results = $SQL->get_result();

$rs = array();
while($rs[] = $results->fetch_assoc()){
    
}

echo json_encode($rs);

$conn->close();
?>