<?php
//$weather_string = file_get_contents('https://api.publicapis.org/entries?category=Weather&https=true');
$weather_string = file_get_contents('postcode.json');
$weather_array = json_decode($weather_string,true);
echo json_encode($weather_array['entries'], true);
?>