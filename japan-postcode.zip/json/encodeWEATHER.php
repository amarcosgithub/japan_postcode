<?php
$weather_string = file_get_contents('weather.json');
$weather_array = json_decode($weather_string,true);
echo json_encode($weather_array['entriesweather'], true);
?>