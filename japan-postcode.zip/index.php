<!DOCTYPE html>
 <html lang="en">
    <head>
        <title>Japan Postcode</title>
        <meta charset="utf-8">        
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/mystyle.css">

        <script type="text/javascript">
            $(document).ready(function(){
                refreshlist(); 
               
                function refreshlist(query){    
                    var searchField = $("#text_content").val();
                    if(searchField === '')  {
                        $('#all-post-codes-list').html('');
                        return;
                    }
                    
                    $.ajax({
                        url:"/japan_postcode/json/encodeJSON.php",
                        type:"GET",
                        success: function(res){
                            
                            var data = JSON.parse(res);
                            
                            var regex = new RegExp(searchField, "i");
                            var temp="<div class='row all-post-codes-list'>";
                            
                            var i=0;
                            $.each(data, function(key, val){
                                if ((val.Address.search(regex) != -1) || (val.Postalcode.search(regex) != -1)) {//IF start      

                                   
                                  $.ajax({
                                    url:"/japan_postcode/json/encodeGMAP.php",
                                    type: "GET",
                                    success: function (gmap_raw) {
                                        var gmap_data = JSON.parse(gmap_raw);


                                        $.each(gmap_data, function(key, gmapval){
                                            var gmap_address = gmapval.Address;
                                            var address = val.Address;

                                            if (address === gmap_address ) { 

                                                 $.ajax({
                                                    url:"/japan_postcode/json/encodeWEATHER.php",
                                                    type: "GET",
                                                    success: function (weather_raw) {
                                                        var weather_data = JSON.parse(weather_raw);
                                                        var date = new Date();
                                                        var DateToday = (date).toString().split(' ').splice(1,3).join(' ');
                                                        var DayToday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
                                                                                                                                                                  
//                                                        
                                                        //tomorrow
                                                        var currentDate = new Date(new Date().getTime() + 24 * 60 * 60 * 1000);
                                                        var day = currentDate.getDate();
                                                        var month = currentDate.getMonth() + 1;
                                                        var year = currentDate.getFullYear();                                                        
                                                      
                                                        //second day
                                                        var secondDay = currentDate.getDate() + 1;
                                                        
                                                        //3rd day
                                                        var numberOfDaysToAdd = 3;
                                                        date.setDate(date.getDate() + numberOfDaysToAdd); 
                                                        
                                                        var dd = date.getDate();
                                                        var mm = date.getMonth() + 1;
                                                        var y = date.getFullYear();
                                                        
                                                        //Weather 3DAY
                                                        Date.prototype.addDays = function(days) {
                                                            var date = new Date(this.valueOf());
                                                            date.setDate(date.getDate() + days);
                                                            return date;
                                                        }
                                                        var date = new Date();

                                                        var i=0;                                   
                                                        $.each(weather_data, function(key, weatherval){
                                                            var weather_address = weatherval.Address;

                                                            if (address === weather_address ) {
                                                                temp += '<div class="col-md-12 well postcode-wrap">';
                                                                    //address, postal code, date
                                                                    temp += '<div class="col-md-12 first-details">';
                                                                        
                                                                        temp += '<div class="col-md-9">';
                                                                            temp += '<div class="address" id="address">'+val.Address+'</div>';
                                                                            temp += '<div class="postcode-num-date-day">';
                                                                                temp += '<span class="pnum">'+val.Postalcode+' | </span>';
                                                                                temp += '<span class="dateToday">'+DateToday+' | </span>';
                                                                                temp += '<span class="day">'+DayToday[date.getDay()]+'</span>';
                                                                            temp += '</div>';
                                                                        temp += '</div>';
                                                                
                                                                        temp += '<div class="col-md-3">';
                                                                            //Today's weather 
                                                                            temp += '<div class="postcode-weather-today-wrap">';
                                                                                temp += '<div class="icon">';
                                                                                    temp += '<div class="degree">';
                                                                                        temp += '<img class="logo-img" src="'+weatherval.Weather_icon+'">';
                                                                                        temp += '<span class="weather">'+weatherval.Weather_state+' |</span>';
                                                                                        temp += '<span class="temp-max">'+weatherval.Temp_max+'&#176; C -</span>';
                                                                                        temp += '<span class="temp-min">'+weatherval.Temp_min+'&#176; C</span>';
                                                                                    temp += '</div>';
                                                                                 temp += '</div>';
                                                                             temp += '</div>';
                                                                        temp += '</div>';    
                                                                    temp += '</div>'; 

                                                                    temp += '<div class="col-md-12 postcode-details-wrap">';
                                                                
                                                                       //next 3 days : start
                                                                        temp += '<div class="col-md-6 col-md-push-3 postcode-weather-next3days-wrap">';
                                                                            temp += '<div class="row">';
                                                                                temp += '<h4 class="">3-day Forecast</h4>';
                                                                                //next day
                                                                                temp += '<div class="col-md-4 col-xs-4 postcode-n3d-wrap">';
                                                                                    temp += '<div class="inside rainy">';  
                                                                                        temp += '<div class="day">'+DayToday[date.getDay()+1]+'</div>';   
                                                                                        temp += '<div class="date">'+ day + '/' + month + '/' + year +'</div>'; 
                                                                                        temp += '<div class="icon">';
                                                                                            temp += '<img class="logo-img" src="'+weatherval.Next_weather[i].next_day.Weather_icon+'">';
                                                                                        temp += '</div>';
                                                                                        temp += '<div class="weatherState">'+weatherval.Next_weather[i].next_day.Weather_state+'</div>';  
                                                                                        temp += '<div class="temp-min">'+weatherval.Next_weather[i].next_day.Temp_min+'&#176;C - <span class="temp-max">'+weatherval.Next_weather[i].next_day.Temp_max+'&#176; C</span></div>';
                                                                                    temp += '</div>';
                                                                                temp += '</div>'; 
//                                                                              //after next day
                                                                                temp += '<div class="col-md-4 col-xs-4 postcode-n3d-wrap">';
                                                                                    temp += '<div class="inside cloudy">';
                                                                                       temp += '<div class="day">'+DayToday[date.getDay()+2]+'</div>';   
                                                                                       temp += '<div class="date">'+ secondDay + '/' + month + '/' + year +'</div>';  
                                                                                       temp += '<div class="icon">';
                                                                                           temp += '<img class="logo-img" src="'+weatherval.Next_weather[i].second_day.Weather_icon+'">';
                                                                                       temp += '</div>';
                                                                                       temp += '<div class="weatherState">'+weatherval.Next_weather[i].second_day.Weather_state+'</div>';
                                                                                       temp += '<div class="temp-min">'+weatherval.Next_weather[i].second_day.Temp_min+'&#176; C - <span class="temp-max">'+weatherval.Next_weather[i].second_day.Temp_max+'&#176; C</span></div>';
                                                                                    temp += '</div>';
                                                                                temp += '</div>';
                                                                                //third day
                                                                                temp += '<div class="col-md-4 col-xs-4 postcode-n3d-wrap">';
                                                                                   temp += '<div class="inside thunder">';   
                                                                                       temp += '<div class="day">'+DayToday[date.getDay()+3]+'</div>';
                                                                                       temp += '<div class="date">'+ dd + '/' + mm + '/' + y +'</div>';
                                                                                       temp += '<div class="icon">';
                                                                                           temp += '<img class="logo-img" src="'+weatherval.Next_weather[i].third_day.Weather_icon+'">';
                                                                                       temp += '</div>';
                                                                                       temp += '<div class="weatherState">'+weatherval.Next_weather[i].third_day.Weather_state+'</div>';
                                                                                       temp += '<div class="temp"><span class="temp-min">'+weatherval.Next_weather[i].third_day.Temp_min+'&#176; C</span> - <span class="temp-max">'+weatherval.Next_weather[i].third_day.Temp_max+'&#176; C</span></div>';
                                                                                   temp += '</div>';
                                                                               temp += '</div>';
                                                                            temp += '</div>';
                                                                        temp += '</div>'; 
//                                                                      //next 3 days : end 
                                                                    temp += '</div>';   

                                                                    // google map : start
                                                                    temp += '<div class="col-md-12 postcode-gmap-wrap">';
                                                                        temp += '<div class="row p0">';
                                                                
                                                                            temp += '<div class="col-md-9 col-sm-9 p0">';
                                                                                temp += '<div id="map">';
                                                                                    temp += '<div class="embed-responsive embed-responsive-100x400px" id="insert_lat2">';
                                                                                        temp += '<iframe src="https://maps.google.com/maps?q='+gmapval.Latitude+','+gmapval.Longitude+'&hl=es;z=14&amp;output=embed" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>';
                                                                                    temp += '</div>';
                                                                                temp += '</div>';
                                                                            temp += '</div>';
                                                                            temp += '<div class="col-md-3 col-sm-3 p0 gmap-image-wrp hidden-xs">';
                                                                                temp += '<img class="gmap-image hidden-xs" src="'+val.Image+'">';
                                                                            temp += '</div>';
                                                                
                                                                            
                                                                        temp += '</div>';
                                                                   temp += '</div>';
                                                                   // google map : end   

                                                                temp += '</div>';
                                                                i++;
                                                            } 
                                                        }); 
                                                        $("#all-post-codes-list").html(temp);
                                                    }
                                                });  
                                            }
                                        }); 
                                    }
                                  });                               

                                } //IF end                   
                            });      
                        }
                    });  
               }

                $('#search').click(function(){
                    var query = $('#text_content').val();
                    refreshlist(query);
                });
                
                
            });

        </script>        
        
    </head>
<body>
    <div class="container">
        <div id="content" class="page_title"><h1>Japan <span>Postal Codes</span></h1></div> 
            
        <div class="row">
            <div class="col-lg-12 mb-2">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search Address or Postal Code" aria-describedby="Search" id="text_content" name="text_content">
                    <span class="input-group-btn">
                        <button class="btn btn-primary" type="button" name="search" id="search">Submit</button>
                    </span>
                </div>
            </div>
         </div>  
    </div>
    <div class="container">
        <div id="all-post-codes-list">         
        </div>        
    </div>
</body>
<html>